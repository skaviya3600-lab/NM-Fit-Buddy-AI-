function toggleMenu() {
    const links = document.getElementById("navLinks");
    if (links) links.classList.toggle("show");
}

document.addEventListener("DOMContentLoaded", () => {
    const dateInput = document.querySelector('input[type="date"]');
    if (dateInput && !dateInput.value) {
        const today = new Date();
        const yyyy = today.getFullYear();
        const mm = String(today.getMonth() + 1).padStart(2, "0");
        const dd = String(today.getDate()).padStart(2, "0");
        dateInput.value = `${yyyy}-${mm}-${dd}`;
    }
});
